package com.example.wedding_hall

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
